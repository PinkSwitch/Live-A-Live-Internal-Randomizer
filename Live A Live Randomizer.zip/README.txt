-LIVE A LIVE RANDOMIZER V1.0-  1/10/2023

Welcome to the Live A Live SFC Randomizer! The randomizer is a modification to the base game allowing for randomization of the game's various elements. Randomization is handled inside of the ROM itself, with no need for seeded roms or external programs. In order to use the randomizer, you will need FLIPS (Or any program that can patch .BPS files), as well as a copy of the 2.0 English fan translation patch. Simply apply the patch over the fan translation ROM, and play. From the title screen, you will be taken to the Randomizer menu, which can be opened at any time during normal gameplay by going to the [Sound] option from the pause screen, and selecting the [Randomizer] option. The game can only save data for one seed at a time, but this seed will persist between save files and resets until another seed has been generated. Settings can be changed mid-game, though Major Characters will not take effect on the current chapter unless it is restarted. For more information, as well as feedback, bug reports, or if you want to be notified for updates, join the Randomizer Discord here:

[ https://discord.gg/9FYrBNjY2x ]

For more general Live A Live content, join Discord A Live.

[ https://discord.gg/ejFTzQwQYD ]

Enjoy! -Pink Switch, 2023

Which patch file should I use?
	(JPR) should be applied over the base JPN sfc ROM. It will also include the translation and apply it automatically.
        (PR) is for manually patched roms that have applied the english translation IPS file over the JP rom.
        (PPR) is for the prepatched Deluxe rom in common circulation.


Changes from the base game:

    -Holding B during dialogue will now automatically skip and close the current textbox. This does not work on choice            prompts, menu text, or the Sci-Fi chapter's terminal text.

    -Text prompts during the Sci-Fi chapter will now accept any input as correct regardless of what was entered.

    -The Trial of Technique will now accept any skill usage to break rocks.

    -Files 3 and 4 have been removed to accomodate saved randomizer data.

    -The Music menu has been replaced with the Randomizer menu and is open from the start of the game.

    -[Hard Protect] and [System Recover] have been slightly tweaked to accomodate weaker characters.

    -Some characters in the Wrestler chapter have received slight buffs to be closer to the chapter's expected difficulty.

    -Fighters can now be refought during the Wrestler chapter.

    -The Knight chapter is now available from the start of the game.
      All chapters must be completed including Knight to unlock the Final Chapter.

    -Characters in the Cowboy chapter have received slight buffs to make the chapter more playable.
  
    -[BonkBonk] and [Teh! Teh!] have been slightly tweaked to make Bel more viable as a starting character.

    -All characters can now learn their skillsets from fighters in the Wrestler chapter, even if those skills are not in the       fighters' moveset. When a character is hit with a skill Masaru could normally learn, that character will learn their         own skill of that respective level. If a character is hit with a learnable attack, but does not gain a skill, it means       that character does not have a corresponding skill in their learnset. Taro and Cube can learn the Robotic Accessory          skills via this method, however they will lose any newly gained skills once the fight has ended. Equipping the               accessories directly will still unlock the skills as normal in all chapters.

    -If major characters are shuffled, the Inheritors will learn the skill in the same slot that the master's character           previously used on them, but will not gain any skills if this is a slot they already had or if this slot has no skill        assigned to it. This will very likely change in the future.
------------------------------------------------------------------------------------------------

Features:
   -Major Characters: Randomize the 8 chapter protagonists. This can result in secondary characters replacing main                characters. No main characters can be duplicates, however a main character may be a duplicate of an existing secondary       character without issue.

   -Character Skills: Randomize which skills each character will learn. Characters will learn one skill on every level, and       some characters may have more skills than they would under normal circumstances. All characters are guranteed to have a      damaging attack skill in the level 1 slot. A single character can not roll duplicate skills, though multiple characters      can potentially share skills.
--------------------------------------------------------------------------------------
Known Issues:

    -Holding B during chapter intro and ending cutscenes skips displaying the text, but the cutscene time is unchanged.

    -Item collection text can be skipped through.

    -Overworld sprites do not currently match the randomized character.

    -Characters with names longer than 6 characters cutoff Great Asia's prefight text.

    -The Xin Shan Quan master's name overfills the name entry textbox in chapters other than Kungfu.

    -The character on the seed/setting input uses incorrect graphics when loaded from the boot menu.
----------------------------------------------------------------------------------------------
Changelog:

1.0- Initial Release